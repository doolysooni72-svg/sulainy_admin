# إعداد المنصات (Android / iOS)

المشروع ده فيه كود Dart بس (lib/ و pubspec.yaml). عشان تشغّله:

## 1) ولّد ملفات المنصات
```bash
flutter create --org com.saliny --project-name saliny_admin .
```
الأمر ده هيضيف مجلدات android/ و ios/ من غير ما يمسح lib/ أو pubspec.yaml
(لو سألك عن استبدال pubspec.yaml قوله لأ).

## 2) نزّل الحزم
```bash
flutter pub get
```

## 3) صلاحيات Android
افتح `android/app/src/main/AndroidManifest.xml` وضيف قبل وسم `<application`:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
<uses-permission android:name="android.permission.CAMERA"/>
<uses-feature android:name="android.hardware.camera" android:required="false"/>
```

وفي `android/app/build.gradle` (أو build.gradle.kts) اظبط:
```
minSdk = 23     // مطلوب لـ mobile_scanner
```

## 4) صلاحيات iOS
افتح `ios/Runner/Info.plist` وضيف جوه `<dict>`:
```xml
<key>NSCameraUsageDescription</key>
<string>نحتاج الكاميرا لمسح الباركود وتصوير إشعار الحوالة</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>نحتاج الوصول للصور لرفع صور المنتجات والإعلانات</string>
```
ولازم iOS deployment target = 13.0 على الأقل (ios/Podfile: `platform :ios, '13.0'`).

## 5) شغّل
```bash
flutter run
```

## بناء APK للتوزيع
```bash
flutter build apk --release
```
الملف هيطلع في: build/app/outputs/flutter-apk/app-release.apk
