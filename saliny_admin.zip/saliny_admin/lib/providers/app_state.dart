import 'package:flutter/foundation.dart';

import '../core/constants.dart';
import '../models/models.dart';
import '../services/api.dart';

/// إحصائيات الداشبورد (محسوبة بعد التصفير)
class DashStats {
  final int totalOrders;
  final double totalRevenue;
  final int mainSalesCount;
  final int kioskSalesCount;
  final int pendingCount;
  final int productsCount;
  final List<Product> lowStock;
  final List<RecentRow> recent;

  DashStats({
    required this.totalOrders,
    required this.totalRevenue,
    required this.mainSalesCount,
    required this.kioskSalesCount,
    required this.pendingCount,
    required this.productsCount,
    required this.lowStock,
    required this.recent,
  });
}

class RecentRow {
  final String source;
  final String name;
  final double total;
  final bool done;
  final DateTime? createdAt;
  RecentRow(this.source, this.name, this.total, this.done, this.createdAt);
}

class AppState extends ChangeNotifier {
  final Api api = Api();

  // --- المصادقة ---
  String? userId;
  String? userEmail;
  String? role;
  String? fatalError;
  bool loggingIn = false;

  bool get isLoggedIn => userId != null;

  List<AppTab> get allowedTabs => roleTabs[role] ?? const [];

  // --- البيانات ---
  List<Product> products = [];
  List<Order> orders = [];
  List<PosSale> posSales = [];
  List<SpecialOrder> specialOrders = [];
  List<Announcement> announcements = [];
  List<PaymentMethod> paymentMethods = [];
  ShopSettings settings = ShopSettings();

  // ================= المصادقة =================
  /// يرجّع رسالة الخطأ أو null عند النجاح
  Future<String?> login(String email, String password) async {
    loggingIn = true;
    notifyListeners();
    try {
      final res = await api.signIn(email, password);
      final user = res.user;
      if (user == null) return 'فشل تسجيل الدخول';
      userId = user.id;
      userEmail = user.email;

      final r = await api.fetchMyRole(user.id);
      if (r == null) {
        fatalError =
            'لم يتم العثور على صلاحياتك في جدول staff_roles. تأكد من ربط حسابك بدور.';
        await api.signOut();
        userId = null;
        return fatalError;
      }
      role = r;
      fatalError = null;
      // أول تحميل للبيانات (لا ننتظره حتى تظهر الشاشة بسرعة)
      loadAllForRole();
      return null;
    } catch (e) {
      return 'فشل تسجيل الدخول: ${_clean(e)}';
    } finally {
      loggingIn = false;
      notifyListeners();
    }
  }

  Future<void> logout() async {
    try {
      await api.signOut();
    } catch (_) {}
    userId = null;
    userEmail = null;
    role = null;
    products = [];
    orders = [];
    posSales = [];
    specialOrders = [];
    announcements = [];
    paymentMethods = [];
    settings = ShopSettings();
    notifyListeners();
  }

  String _clean(Object e) => e.toString().replaceFirst('Exception: ', '');

  void _setError(String prefix, Object e) {
    fatalError = '$prefix: ${_clean(e)}';
    notifyListeners();
  }

  void clearError() {
    fatalError = null;
    notifyListeners();
  }

  // ================= تحميل البيانات حسب الدور =================
  Future<void> loadAllForRole() async {
    switch (role) {
      case 'admin':
        await Future.wait([
          loadProducts(),
          loadOrders(),
          loadPosSales(),
          loadSpecialOrders(),
          loadAnnouncements(),
          loadPaymentMethods(),
          loadSettings(),
        ]);
        break;
      case 'orders':
        await Future.wait([loadOrders(), loadSpecialOrders()]);
        break;
      case 'support':
        await loadAnnouncements();
        break;
      case 'pos':
      case 'pos_kiosk':
        await loadProducts();
        break;
      case 'customer_service':
        // خدمة العملاء بتقرأ الطلبات والطلبات الخاصة (عرض فقط)
        await Future.wait([loadOrders(), loadSpecialOrders()]);
        break;
    }
  }

  Future<void> loadProducts() async {
    try {
      products = await api.fetchProducts();
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل المنتجات', e);
    }
  }

  Future<void> loadOrders() async {
    try {
      orders = await api.fetchOrders();
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل الطلبات', e);
    }
  }

  Future<void> loadPosSales() async {
    try {
      posSales = await api.fetchPosSales();
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل مبيعات النافذة', e);
    }
  }

  Future<void> loadSpecialOrders() async {
    try {
      specialOrders = await api.fetchSpecialOrders();
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل الطلبات الخاصة', e);
    }
  }

  Future<void> loadAnnouncements() async {
    try {
      announcements = await api.fetchAnnouncements();
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل الإعلانات', e);
    }
  }

  Future<void> loadPaymentMethods() async {
    try {
      paymentMethods = await api.fetchPaymentMethods();
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل طرق الدفع', e);
    }
  }

  Future<void> loadSettings() async {
    try {
      final s = await api.fetchSettings();
      if (s != null) settings = s;
      notifyListeners();
    } catch (e) {
      _setError('تعذر تحميل الإعدادات', e);
    }
  }

  // ================= إجراءات =================
  Future<void> markOrderDone(String id) async {
    try {
      await api.markOrderDone(id);
      await loadOrders();
    } catch (e) {
      _setError('تعذر تحديث الطلب', e);
    }
  }

  Future<void> deleteOrder(String id) async {
    try {
      await api.deleteOrder(id);
      await loadOrders();
    } catch (e) {
      _setError('تعذر حذف الطلب', e);
    }
  }

  Future<void> markSpecialDone(String id) async {
    try {
      await api.markSpecialDone(id);
      await loadSpecialOrders();
    } catch (e) {
      _setError('خطأ', e);
    }
  }

  Future<void> deleteSpecial(String id) async {
    try {
      await api.deleteSpecial(id);
      await loadSpecialOrders();
    } catch (e) {
      _setError('خطأ', e);
    }
  }

  Future<void> deleteProduct(String id) async {
    try {
      await api.deleteProduct(id);
      await loadProducts();
    } catch (e) {
      _setError('تعذر حذف المنتج', e);
    }
  }

  Future<void> deleteAnnouncement(String id) async {
    try {
      await api.deleteAnnouncement(id);
      await loadAnnouncements();
    } catch (e) {
      _setError('خطأ', e);
    }
  }

  Future<void> deletePaymentMethod(String id) async {
    try {
      await api.deletePaymentMethod(id);
      await loadPaymentMethods();
    } catch (e) {
      _setError('خطأ', e);
    }
  }

  // ---- تصفير الإحصائيات ----
  Future<void> resetStats() async {
    try {
      final now = DateTime.now();
      await api.setStatsResetAt(now);
      settings = ShopSettings(
        shopName: settings.shopName,
        whatsapp: settings.whatsapp,
        facebook: settings.facebook,
        customerServiceNumber: settings.customerServiceNumber,
        location: settings.location,
        termsText: settings.termsText,
        statsResetAt: now,
      );
      notifyListeners();
    } catch (e) {
      _setError('تعذر التصفير', e);
    }
  }

  Future<void> undoStatsReset() async {
    try {
      await api.setStatsResetAt(null);
      settings = ShopSettings(
        shopName: settings.shopName,
        whatsapp: settings.whatsapp,
        facebook: settings.facebook,
        customerServiceNumber: settings.customerServiceNumber,
        location: settings.location,
        termsText: settings.termsText,
        statsResetAt: null,
      );
      notifyListeners();
    } catch (e) {
      _setError('تعذر التراجع', e);
    }
  }

  // ================= الداشبورد =================
  DashStats computeDashboard() {
    final cutoff = settings.statsResetAt;
    bool after(DateTime? d) =>
        cutoff == null || (d != null && d.isAfter(cutoff));

    final doneOrders = orders.where((o) => o.isDone && after(o.createdAt));
    final mainSales =
        posSales.where((p) => !p.isKiosk && after(p.createdAt)).toList();
    final kioskSales =
        posSales.where((p) => p.isKiosk && after(p.createdAt)).toList();

    final onlineRev = doneOrders.fold<double>(0, (s, o) => s + o.total);
    final mainRev = mainSales.fold<double>(0, (s, p) => s + p.total);
    final kioskRev = kioskSales.fold<double>(0, (s, p) => s + p.total);

    final low = products
        .where((p) => p.stock > 0 && p.stock <= Config.lowStockThreshold)
        .toList()
      ..sort((a, b) => a.stock.compareTo(b.stock));

    final combined = <RecentRow>[
      ...orders
          .where((o) => after(o.createdAt))
          .map((o) => RecentRow('أونلاين', o.name, o.total, o.isDone, o.createdAt)),
      ...mainSales
          .map((s) => RecentRow('بيع النافذة', 'بيع نافذة', s.total, true, s.createdAt)),
      ...kioskSales
          .map((s) => RecentRow('الكشك', 'بيع كشك', s.total, true, s.createdAt)),
    ]..sort((a, b) => (b.createdAt ?? DateTime(0))
        .compareTo(a.createdAt ?? DateTime(0)));

    return DashStats(
      totalOrders: orders.length,
      totalRevenue: onlineRev + mainRev + kioskRev,
      mainSalesCount: mainSales.length,
      kioskSalesCount: kioskSales.length,
      pendingCount: orders.where((o) => o.status == 'pending').length,
      productsCount: products.length,
      lowStock: low,
      recent: combined.take(8).toList(),
    );
  }
}
