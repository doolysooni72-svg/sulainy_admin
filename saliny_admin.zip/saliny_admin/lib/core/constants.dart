import 'package:intl/intl.dart';

class Config {
  static const supabaseUrl = 'https://niehsvflklneawijoksh.supabase.co';
  static const supabaseKey = 'sb_publishable_k_t9MBQo-w8-P1ix5uW_6w_55K7lxAa';

  // Storage buckets (نفس الموجودة في النسخة الويب)
  static const bucketProducts = 'product-images';
  static const bucketAnnouncements = 'announcement-images';
  static const bucketPaymentQr = 'payment-qr';
  static const bucketTransfers = 'transfer-notifications';

  /// حد المخزون المنخفض
  static const lowStockThreshold = 3;
}

/// معرّفات التبويبات (نفس data-tab في النسخة الويب)
enum AppTab {
  dash('الرئيسية'),
  prod('المنتجات'),
  ord('الطلبات'),
  special('طلبات خاصة'),
  cs('خدمة العملاء'),
  announce('الإعلانات'),
  pay('طرق الدفع'),
  pos('بيع النافذة'),
  kiosk('بيع الكشك'),
  reports('تقارير المبيعات'),
  settings('الإعدادات');

  final String label;
  const AppTab(this.label);
}

/// الصلاحيات: نفس roleTabs في النسخة الويب بالظبط
const Map<String, List<AppTab>> roleTabs = {
  'admin': [
    AppTab.dash,
    AppTab.prod,
    AppTab.ord,
    AppTab.special,
    AppTab.cs,
    AppTab.announce,
    AppTab.pay,
    AppTab.pos,
    AppTab.kiosk,
    AppTab.reports,
    AppTab.settings,
  ],
  'orders': [AppTab.ord, AppTab.special],
  'support': [AppTab.announce],
  'pos': [AppTab.pos],
  'pos_kiosk': [AppTab.kiosk],
  'customer_service': [AppTab.cs],
};

// ---------- تنسيقات ----------
final _numFmt = NumberFormat.decimalPattern('ar_EG');
final _dateFmt = DateFormat('d/M/yyyy hh:mm a', 'ar_EG');

String money(num? n) => '${_numFmt.format(n ?? 0)} جنيه';

String fmtDate(DateTime? d) => d == null ? '-' : _dateFmt.format(d.toLocal());
