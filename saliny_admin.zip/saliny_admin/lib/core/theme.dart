import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// نفس ألوان لوحة التحكم الأصلية (كحلي + فضي + أزرق)
class AppColors {
  static const bgNavy = Color(0xFF050C18);
  static const panelNavy = Color(0xFF0C1626);
  static const panelNavy2 = Color(0xFF111F35);
  static const inputBg = Color(0xFF081120);
  static const borderSilver = Color(0xFF3D4C60);
  static const divider = Color(0xFF1A2740);
  static const accentBlue = Color(0xFF4A90D9);

  static const textMain = Color(0xFFE4E9EF);
  static const textSoft = Color(0xFFD0D8E2);
  static const textLabel = Color(0xFF9DB3CC);
  static const textTitle = Color(0xFFCFE0F5);
  static const textMuted = Color(0xFF7D8BA0);
  static const textDim = Color(0xFF5C6B80);
  static const priceBlue = Color(0xFF9DC4F0);

  static const success = Color(0xFF7FD8A8);
  static const successBg = Color(0xFF1F4A34);
  static const danger = Color(0xFFE8899A);
  static const dangerBg = Color(0xFF4A2130);
  static const warning = Color(0xFFE0C060);
  static const offer = Color(0xFFE0839A);
  static const editBg = Color(0xFF1E3A5F);

  static const silverGradient = LinearGradient(
    begin: Alignment.centerLeft,
    end: Alignment.centerRight,
    colors: [
      Color(0xFF9AA5B1),
      Color(0xFFE8EDF2),
      Color(0xFFC3CDD8),
      Color(0xFFF4F7FA),
      Color(0xFF8B96A3),
    ],
  );
}

ThemeData buildAppTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  final textTheme = GoogleFonts.cairoTextTheme(base.textTheme).apply(
    bodyColor: AppColors.textMain,
    displayColor: AppColors.textMain,
  );

  OutlineInputBorder border(Color c) => OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: BorderSide(color: c),
      );

  return base.copyWith(
    scaffoldBackgroundColor: AppColors.bgNavy,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.accentBlue,
      secondary: AppColors.accentBlue,
      surface: AppColors.panelNavy,
      error: AppColors.danger,
    ),
    textTheme: textTheme,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.bgNavy,
      elevation: 0,
      centerTitle: false,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: AppColors.inputBg,
      contentPadding: const EdgeInsets.all(12),
      labelStyle: const TextStyle(color: AppColors.textLabel),
      hintStyle: const TextStyle(color: AppColors.textDim),
      border: border(AppColors.borderSilver),
      enabledBorder: border(AppColors.borderSilver),
      focusedBorder: border(AppColors.accentBlue),
    ),
    checkboxTheme: CheckboxThemeData(
      fillColor: WidgetStateProperty.resolveWith(
        (s) => s.contains(WidgetState.selected)
            ? AppColors.accentBlue
            : Colors.transparent,
      ),
      side: const BorderSide(color: AppColors.borderSilver, width: 1.5),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: AppColors.panelNavy2,
      contentTextStyle: GoogleFonts.cairo(color: AppColors.textMain),
      behavior: SnackBarBehavior.floating,
    ),
    // لون خلفية الحوارات (بدل DialogTheme لأن اسمه اتغير بين إصدارات Flutter)
    dialogBackgroundColor: AppColors.panelNavy,
  );
}
