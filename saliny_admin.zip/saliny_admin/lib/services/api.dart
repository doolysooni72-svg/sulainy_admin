import 'dart:io';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/constants.dart';
import '../models/models.dart';

/// طبقة الاتصال بـ Supabase — نفس الجداول والـ RPC المستخدمة في نسخة الويب.
class Api {
  SupabaseClient get _db => Supabase.instance.client;

  // ================= المصادقة =================
  Future<AuthResponse> signIn(String email, String password) =>
      _db.auth.signInWithPassword(email: email, password: password);

  Future<void> signOut() => _db.auth.signOut();

  Future<void> changePassword(String newPassword) async {
    await _db.auth.updateUser(UserAttributes(password: newPassword));
  }

  User? get currentUser => _db.auth.currentUser;

  Future<String?> fetchMyRole(String userId) async {
    final data = await _db
        .from('staff_roles')
        .select('role')
        .eq('user_id', userId);
    if (data.isEmpty) return null;
    return data.first['role'] as String?;
  }

  // ================= المنتجات =================
  Future<List<Product>> fetchProducts() async {
    final data =
        await _db.from('products').select().order('created_at', ascending: false);
    return data.map<Product>((e) => Product.fromJson(e)).toList();
  }

  Future<void> saveProduct({
    String? editingId,
    required String title,
    required String description,
    required double price,
    required int stock,
    required bool isOffer,
    double? originalPrice,
    String? barcode,
    String? imageUrl,
  }) async {
    final payload = <String, dynamic>{
      'title': title,
      'description': description,
      'price': price,
      'stock': stock,
      'is_offer': isOffer,
      'original_price': originalPrice,
      'barcode': (barcode == null || barcode.isEmpty) ? null : barcode,
    };
    if (imageUrl != null) payload['image_url'] = imageUrl;

    if (editingId != null) {
      await _db.from('products').update(payload).eq('id', editingId);
    } else {
      payload['image_url'] ??= null;
      await _db.from('products').insert(payload);
    }
  }

  Future<void> deleteProduct(String id) =>
      _db.from('products').delete().eq('id', id);

  // ================= الطلبات =================
  Future<List<Order>> fetchOrders() async {
    final data =
        await _db.from('orders').select().order('created_at', ascending: false);
    return data.map<Order>((e) => Order.fromJson(e)).toList();
  }

  Future<void> markOrderDone(String id) =>
      _db.from('orders').update({'status': 'done'}).eq('id', id);

  Future<void> deleteOrder(String id) =>
      _db.from('orders').delete().eq('id', id);

  // ================= الطلبات الخاصة =================
  Future<List<SpecialOrder>> fetchSpecialOrders() async {
    final data = await _db
        .from('special_orders')
        .select()
        .order('created_at', ascending: false);
    return data.map<SpecialOrder>((e) => SpecialOrder.fromJson(e)).toList();
  }

  Future<void> markSpecialDone(String id) =>
      _db.from('special_orders').update({'status': 'done'}).eq('id', id);

  Future<void> deleteSpecial(String id) =>
      _db.from('special_orders').delete().eq('id', id);

  // ================= الإعلانات =================
  Future<List<Announcement>> fetchAnnouncements() async {
    final data = await _db
        .from('announcements')
        .select()
        .order('created_at', ascending: false);
    return data.map<Announcement>((e) => Announcement.fromJson(e)).toList();
  }

  Future<void> addAnnouncement(String text, String? imageUrl) async {
    final payload = <String, dynamic>{'text': text};
    if (imageUrl != null) payload['image_url'] = imageUrl;
    await _db.from('announcements').insert(payload);
  }

  Future<void> deleteAnnouncement(String id) =>
      _db.from('announcements').delete().eq('id', id);

  // ================= طرق الدفع =================
  Future<List<PaymentMethod>> fetchPaymentMethods() async {
    final data = await _db
        .from('payment_methods')
        .select()
        .order('created_at', ascending: false);
    return data.map<PaymentMethod>((e) => PaymentMethod.fromJson(e)).toList();
  }

  Future<void> addPaymentMethod(
      String name, String? account, String? qrUrl) async {
    final payload = <String, dynamic>{
      'name': name,
      'account_number': (account == null || account.isEmpty) ? null : account,
    };
    if (qrUrl != null) payload['qr_image_url'] = qrUrl;
    await _db.from('payment_methods').insert(payload);
  }

  Future<void> deletePaymentMethod(String id) =>
      _db.from('payment_methods').delete().eq('id', id);

  // ================= بيع النافذة / الكشك =================
  Future<List<PosSale>> fetchPosSales() async {
    final data = await _db
        .from('pos_sales')
        .select('id,items,total,location,created_at')
        .order('created_at', ascending: false);
    return data.map<PosSale>((e) => PosSale.fromJson(e)).toList();
  }

  /// يسجّل البيع ثم يخصم المخزون. يرجّع id عملية البيع.
  Future<String> completeSale({
    required List<CartItem> cart,
    required String location, // main | kiosk
    required String soldBy,
  }) async {
    final items = cart
        .map((c) => {'title': c.title, 'price': c.price, 'qty': c.qty})
        .toList();
    final total = cart.fold<double>(0, (s, c) => s + c.price * c.qty);

    final inserted = await _db
        .from('pos_sales')
        .insert({
          'items': items,
          'total': total,
          'sold_by': soldBy,
          'location': location,
        })
        .select('id')
        .single();

    // خصم المخزون عبر نفس الـ RPC المستخدم في الويب
    await Future.wait(cart.map((c) => _db.rpc(
          'decrement_stock',
          params: {'p_id': c.productId, 'qty': c.qty},
        )));

    return inserted['id'].toString();
  }

  Future<void> attachSaleReceipt(String saleId, String url) => _db
      .from('pos_sales')
      .update({'payment_screenshot_url': url}).eq('id', saleId);

  // ================= التقارير =================
  Future<List<Map<String, dynamic>>> fetchOrdersForReport(
      DateTime? from, DateTime? to) async {
    var q = _db.from('orders').select('items,created_at');
    if (from != null) q = q.gte('created_at', _dayStart(from));
    if (to != null) q = q.lte('created_at', _dayEnd(to));
    return List<Map<String, dynamic>>.from(await q);
  }

  Future<List<Map<String, dynamic>>> fetchPosForReport(
      DateTime? from, DateTime? to) async {
    var q = _db.from('pos_sales').select('items,location,created_at');
    if (from != null) q = q.gte('created_at', _dayStart(from));
    if (to != null) q = q.lte('created_at', _dayEnd(to));
    return List<Map<String, dynamic>>.from(await q);
  }

  String _dayStart(DateTime d) =>
      DateTime(d.year, d.month, d.day).toUtc().toIso8601String();
  String _dayEnd(DateTime d) =>
      DateTime(d.year, d.month, d.day, 23, 59, 59).toUtc().toIso8601String();

  // ================= الإعدادات =================
  Future<ShopSettings?> fetchSettings() async {
    final data = await _db.from('settings').select().eq('id', 'main');
    if (data.isEmpty) return null;
    return ShopSettings.fromJson(data.first);
  }

  Future<void> saveSettings({
    required String shopName,
    required String whatsapp,
    required String facebook,
    required String customerService,
    required String location,
    required String terms,
  }) =>
      _db.from('settings').update({
        'shop_name': shopName,
        'whatsapp': whatsapp,
        'facebook': facebook.isEmpty ? '#' : facebook,
        'customer_service_number': customerService,
        'location': location,
        'terms_text': terms,
      }).eq('id', 'main');

  Future<void> setStatsResetAt(DateTime? when) => _db
      .from('settings')
      .update({'stats_reset_at': when?.toUtc().toIso8601String()}).eq(
          'id', 'main');

  // ================= رفع الصور =================
  /// يضغط الصورة ثم يرفعها ويرجّع الرابط العام.
  Future<String> uploadImage({
    required File file,
    required String bucket,
    String prefix = '',
    int maxDim = 1280,
    int quality = 72,
    bool png = false,
  }) async {
    final compressed = await _compress(file, maxDim, quality, png);
    final ext = png ? 'png' : 'jpg';
    final path = '${DateTime.now().millisecondsSinceEpoch}$prefix.$ext';

    await _db.storage.from(bucket).upload(
          path,
          compressed,
          fileOptions: FileOptions(
            contentType: png ? 'image/png' : 'image/jpeg',
            upsert: false,
          ),
        );
    return _db.storage.from(bucket).getPublicUrl(path);
  }

  Future<File> _compress(File src, int maxDim, int quality, bool png) async {
    try {
      final dir = await getTemporaryDirectory();
      final target =
          '${dir.path}/${DateTime.now().microsecondsSinceEpoch}.${png ? 'png' : 'jpg'}';
      final out = await FlutterImageCompress.compressAndGetFile(
        src.absolute.path,
        target,
        minWidth: maxDim,
        minHeight: maxDim,
        quality: quality,
        format: png ? CompressFormat.png : CompressFormat.jpeg,
      );
      if (out == null) return src;
      final f = File(out.path);
      // لو الضغط كبّر الحجم نرجع للأصلي (نفس منطق النسخة الويب)
      return (await f.length()) >= (await src.length()) ? src : f;
    } catch (_) {
      return src;
    }
  }
}
