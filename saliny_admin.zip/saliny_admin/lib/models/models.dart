DateTime? _parseDate(dynamic v) =>
    v == null ? null : DateTime.tryParse(v.toString());

double _num(dynamic v) => v == null ? 0 : (v as num).toDouble();

class Product {
  final String id;
  final String title;
  final String description;
  final double price;
  final int stock;
  final String? imageUrl;
  final bool isOffer;
  final double? originalPrice;
  final String barcode;

  Product({
    required this.id,
    required this.title,
    required this.description,
    required this.price,
    required this.stock,
    this.imageUrl,
    this.isOffer = false,
    this.originalPrice,
    this.barcode = '',
  });

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'].toString(),
        title: j['title'] ?? '',
        description: j['description'] ?? '',
        price: _num(j['price']),
        stock: (j['stock'] as num?)?.toInt() ?? 0,
        imageUrl: j['image_url'],
        isOffer: j['is_offer'] == true,
        originalPrice:
            j['original_price'] == null ? null : _num(j['original_price']),
        barcode: j['barcode'] ?? '',
      );
}

/// سطر داخل طلب / فاتورة (الحقول: title, price, qty)
class LineItem {
  final String title;
  final double price;
  final int qty;

  LineItem({required this.title, required this.price, required this.qty});

  factory LineItem.fromJson(Map<String, dynamic> j) => LineItem(
        title: j['title'] ?? '',
        price: _num(j['price']),
        qty: (j['qty'] as num?)?.toInt() ?? 0,
      );

  Map<String, dynamic> toJson() => {'title': title, 'price': price, 'qty': qty};
}

List<LineItem> _items(dynamic v) => (v as List? ?? [])
    .map((e) => LineItem.fromJson(Map<String, dynamic>.from(e)))
    .toList();

class Order {
  final String id;
  final String name;
  final String phone;
  final String deliveryAddress;
  final String gpsLink;
  final List<LineItem> items;
  final double total;
  final String status;
  final DateTime? createdAt;
  final String receiptUrl;

  Order({
    required this.id,
    required this.name,
    required this.phone,
    required this.deliveryAddress,
    required this.gpsLink,
    required this.items,
    required this.total,
    required this.status,
    required this.createdAt,
    required this.receiptUrl,
  });

  bool get isDone => status == 'done';

  String get itemsText => items.map((i) => '${i.title} ×${i.qty}').join('، ');

  factory Order.fromJson(Map<String, dynamic> j) => Order(
        id: j['id'].toString(),
        name: j['name'] ?? '',
        phone: j['phone'] ?? '',
        deliveryAddress: j['delivery_address'] ?? '',
        gpsLink: j['gps_link'] ?? '',
        items: _items(j['items']),
        total: _num(j['total']),
        status: j['status'] ?? 'pending',
        createdAt: _parseDate(j['created_at']),
        receiptUrl: j['payment_screenshot_url'] ?? '',
      );
}

class PosSale {
  final String id;
  final List<LineItem> items;
  final double total;
  final String location; // main | kiosk
  final DateTime? createdAt;

  PosSale({
    required this.id,
    required this.items,
    required this.total,
    required this.location,
    required this.createdAt,
  });

  bool get isKiosk => location == 'kiosk';

  factory PosSale.fromJson(Map<String, dynamic> j) => PosSale(
        id: j['id'].toString(),
        items: _items(j['items']),
        total: _num(j['total']),
        location: j['location'] ?? 'main',
        createdAt: _parseDate(j['created_at']),
      );
}

class SpecialOrder {
  final String id;
  final String name;
  final String phone;
  final String description;
  final String status;
  final DateTime? createdAt;

  SpecialOrder({
    required this.id,
    required this.name,
    required this.phone,
    required this.description,
    required this.status,
    required this.createdAt,
  });

  bool get isDone => status == 'done';

  factory SpecialOrder.fromJson(Map<String, dynamic> j) => SpecialOrder(
        id: j['id'].toString(),
        name: j['name'] ?? '',
        phone: j['phone'] ?? '',
        description: j['description'] ?? '',
        status: j['status'] ?? 'pending',
        createdAt: _parseDate(j['created_at']),
      );
}

class Announcement {
  final String id;
  final String text;
  final String? imageUrl;

  Announcement({required this.id, required this.text, this.imageUrl});

  factory Announcement.fromJson(Map<String, dynamic> j) => Announcement(
        id: j['id'].toString(),
        text: j['text'] ?? '',
        imageUrl: j['image_url'],
      );
}

class PaymentMethod {
  final String id;
  final String name;
  final String? accountNumber;
  final String? qrUrl;

  PaymentMethod({
    required this.id,
    required this.name,
    this.accountNumber,
    this.qrUrl,
  });

  factory PaymentMethod.fromJson(Map<String, dynamic> j) => PaymentMethod(
        id: j['id'].toString(),
        name: j['name'] ?? '',
        accountNumber: j['account_number'],
        qrUrl: j['qr_image_url'],
      );
}

class ShopSettings {
  final String shopName;
  final String whatsapp;
  final String facebook;
  final String customerServiceNumber;
  final String location;
  final String termsText;
  final DateTime? statsResetAt;

  ShopSettings({
    this.shopName = '',
    this.whatsapp = '',
    this.facebook = '',
    this.customerServiceNumber = '',
    this.location = '',
    this.termsText = '',
    this.statsResetAt,
  });

  factory ShopSettings.fromJson(Map<String, dynamic> j) => ShopSettings(
        shopName: j['shop_name'] ?? '',
        whatsapp: j['whatsapp'] ?? '',
        facebook: j['facebook'] ?? '',
        customerServiceNumber: j['customer_service_number'] ?? '',
        location: j['location'] ?? '',
        termsText: j['terms_text'] ?? '',
        statsResetAt: _parseDate(j['stats_reset_at']),
      );
}

/// عنصر في سلة بيع النافذة / الكشك
class CartItem {
  final String productId;
  final String title;
  final double price;
  final int maxStock;
  int qty;

  CartItem({
    required this.productId,
    required this.title,
    required this.price,
    required this.maxStock,
    this.qty = 1,
  });
}
