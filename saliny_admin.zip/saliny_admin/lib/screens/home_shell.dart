import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/constants.dart';
import '../core/theme.dart';
import '../providers/app_state.dart';
import '../widgets/common.dart';
import 'tabs/announcements_tab.dart';
import 'tabs/cs_tab.dart';
import 'tabs/dashboard_tab.dart';
import 'tabs/orders_tab.dart';
import 'tabs/payment_tab.dart';
import 'tabs/pos_tab.dart';
import 'tabs/products_tab.dart';
import 'tabs/reports_tab.dart';
import 'tabs/settings_tab.dart';
import 'tabs/special_orders_tab.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  AppTab? _current;
  bool _refreshing = false;

  /// يسمح للتبويبات بالتنقل لتبويب آخر (مثلاً "تعديل" يفتح المنتجات)
  void goTo(AppTab tab) => setState(() => _current = tab);

  Widget _buildTab(AppTab tab) {
    switch (tab) {
      case AppTab.dash:
        return const DashboardTab();
      case AppTab.prod:
        return const ProductsTab();
      case AppTab.ord:
        return const OrdersTab();
      case AppTab.special:
        return const SpecialOrdersTab();
      case AppTab.cs:
        return const CsTab();
      case AppTab.announce:
        return const AnnouncementsTab();
      case AppTab.pay:
        return const PaymentTab();
      case AppTab.pos:
        return const PosTab(kiosk: false);
      case AppTab.kiosk:
        return const PosTab(kiosk: true);
      case AppTab.reports:
        return const ReportsTab();
      case AppTab.settings:
        return const SettingsTab();
    }
  }

  Future<void> _refresh() async {
    setState(() => _refreshing = true);
    await context.read<AppState>().loadAllForRole();
    if (mounted) setState(() => _refreshing = false);
  }

  Future<void> _logout() async {
    final ok = await confirmDialog(context, 'هل تريد تسجيل الخروج؟');
    if (ok && mounted) context.read<AppState>().logout();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final tabs = s.allowedTabs;

    if (tabs.isEmpty) {
      return Scaffold(
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('لا توجد صلاحيات لهذا الحساب'),
              const SizedBox(height: 12),
              OutlineBtn(
                  label: 'خروج', fullWidth: false, onPressed: s.logout),
            ],
          ),
        ),
      );
    }

    // لو التبويب الحالي مش مسموح أو لسه ما اتحددش → أول تبويب مسموح
    final current = (_current != null && tabs.contains(_current))
        ? _current!
        : tabs.first;
    final showNav = tabs.length > 1;

    return Scaffold(
      body: GlowBackground(
        child: SafeArea(
          child: Column(
            children: [
              // ---- بانر الأخطاء ----
              if (s.fatalError != null)
                Material(
                  color: const Color(0xFF7A1010),
                  child: InkWell(
                    onTap: s.clearError,
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(s.fatalError!,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: Colors.white, fontSize: 13)),
                          ),
                          const Icon(Icons.close, size: 16, color: Colors.white70),
                        ],
                      ),
                    ),
                  ),
                ),

              // ---- الشريط العلوي ----
              Container(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
                decoration: const BoxDecoration(
                  border: Border(
                      bottom: BorderSide(color: AppColors.borderSilver)),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SilverText('لوحة التحكم — نظام المبيعات',
                              size: 17),
                          const SizedBox(height: 2),
                          Text(s.userEmail ?? '',
                              style: const TextStyle(
                                  color: AppColors.textDim, fontSize: 12)),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'تحديث',
                      onPressed: _refreshing ? null : _refresh,
                      icon: _refreshing
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.refresh,
                              color: AppColors.textLabel),
                    ),
                    IconButton(
                      tooltip: 'خروج',
                      onPressed: _logout,
                      icon: const Icon(Icons.logout, color: AppColors.danger),
                    ),
                  ],
                ),
              ),

              // ---- شريط التبويبات ----
              if (showNav)
                Container(
                  height: 46,
                  decoration: const BoxDecoration(
                    border:
                        Border(bottom: BorderSide(color: AppColors.divider)),
                  ),
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    itemCount: tabs.length,
                    itemBuilder: (_, i) {
                      final t = tabs[i];
                      final active = t == current;
                      return InkWell(
                        onTap: () => goTo(t),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            border: Border(
                              bottom: BorderSide(
                                color: active
                                    ? AppColors.accentBlue
                                    : Colors.transparent,
                                width: 2,
                              ),
                            ),
                          ),
                          child: Text(
                            t.label,
                            style: TextStyle(
                              color: active
                                  ? AppColors.accentBlue
                                  : AppColors.textDim,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),

              // ---- المحتوى ----
              Expanded(
                child: RefreshIndicator(
                  onRefresh: () => context.read<AppState>().loadAllForRole(),
                  color: AppColors.accentBlue,
                  backgroundColor: AppColors.panelNavy,
                  child: _KeepAlive(
                    key: ValueKey(current),
                    child: _buildTab(current),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _KeepAlive extends StatelessWidget {
  final Widget child;
  const _KeepAlive({super.key, required this.child});
  @override
  Widget build(BuildContext context) => child;
}
