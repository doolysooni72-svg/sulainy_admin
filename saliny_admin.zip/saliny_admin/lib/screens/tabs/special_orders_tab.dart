import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';
import 'orders_tab.dart' show InfoLine;

/// كارت طلب خاص — بإجراءات أو عرض فقط
class SpecialOrderCard extends StatelessWidget {
  final SpecialOrder order;
  final bool readOnly;
  const SpecialOrderCard({super.key, required this.order, this.readOnly = false});

  @override
  Widget build(BuildContext context) {
    final s = order;
    final state = context.read<AppState>();

    return Panel(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(s.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15.5)),
              ),
              Pill.status(s.isDone),
            ],
          ),
          const SizedBox(height: 10),
          InfoLine('الهاتف',
              Text(s.phone, style: const TextStyle(color: AppColors.textSoft))),
          InfoLine('الوصف',
              Text(s.description,
                  style: const TextStyle(color: AppColors.textSoft, height: 1.5))),
          InfoLine('التاريخ',
              Text(fmtDate(s.createdAt),
                  style: const TextStyle(color: AppColors.textSoft))),
          if (!readOnly) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                if (!s.isDone) ...[
                  MiniButton('إتمام', MiniKind.done,
                      () => state.markSpecialDone(s.id)),
                  const SizedBox(width: 8),
                ],
                MiniButton('حذف', MiniKind.del, () async {
                  final ok =
                      await confirmDialog(context, 'حذف هذا الطلب الخاص؟');
                  if (ok) state.deleteSpecial(s.id);
                }),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class SpecialOrdersTab extends StatelessWidget {
  const SpecialOrdersTab({super.key});

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().specialOrders;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        SectionTitle('الطلبات الخاصة (${list.length})'),
        if (list.isEmpty)
          const Panel(child: EmptyText('لا توجد طلبات خاصة'))
        else
          ...list.map((s) => SpecialOrderCard(order: s)),
      ],
    );
  }
}
