import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';

class AnnouncementsTab extends StatefulWidget {
  const AnnouncementsTab({super.key});

  @override
  State<AnnouncementsTab> createState() => _AnnouncementsTabState();
}

class _AnnouncementsTabState extends State<AnnouncementsTab> {
  final _text = TextEditingController();
  File? _image;
  bool _saving = false;
  String? _msg;
  bool _msgError = false;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => _image = File(x.path));
  }

  Future<void> _save() async {
    final text = _text.text.trim();
    if (text.isEmpty) {
      setState(() {
        _msg = 'الرجاء كتابة نص الإعلان';
        _msgError = true;
      });
      return;
    }
    final state = context.read<AppState>();
    setState(() {
      _saving = true;
      _msg = null;
    });
    try {
      String? url;
      if (_image != null) {
        try {
          url = await state.api.uploadImage(
              file: _image!, bucket: Config.bucketAnnouncements);
        } catch (e) {
          throw 'تعذر رفع الصورة: $e';
        }
      }
      await state.api.addAnnouncement(text, url);
      _text.clear();
      _image = null;
      await state.loadAnnouncements();
      if (mounted) {
        setState(() {
          _msg = 'تم نشر الإعلان';
          _msgError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _msg = e.toString().startsWith('تعذر رفع') ? e.toString() : 'خطأ: $e';
          _msgError = true;
        });
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().announcements;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('إضافة إعلان'),
              LabeledField(label: 'نص الإعلان', controller: _text, maxLines: 5),
              const Text('صورة (اختياري)',
                  style: TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
              const SizedBox(height: 6),
              Row(
                children: [
                  if (_image != null)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(_image!,
                            width: 48, height: 48, fit: BoxFit.cover),
                      ),
                    ),
                  Expanded(
                    child: OutlineBtn(
                      label: _image == null ? 'اختيار صورة' : 'تغيير الصورة',
                      icon: Icons.image_outlined,
                      onPressed: _pick,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SilverButton(
                  label: 'نشر الإعلان', loading: _saving, onPressed: _save),
              StatusMsg(_msg, error: _msgError),
            ],
          ),
        ),
        const SectionTitle('الإعلانات الحالية'),
        if (list.isEmpty)
          const Panel(child: EmptyText('لا توجد إعلانات'))
        else
          ...list.map((a) => Panel(
                padding: const EdgeInsets.all(14),
                margin: const EdgeInsets.only(bottom: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (a.imageUrl != null && a.imageUrl!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: CachedNetworkImage(
                            imageUrl: a.imageUrl!,
                            width: double.infinity,
                            height: 160,
                            fit: BoxFit.cover,
                            errorWidget: (_, __, ___) => const SizedBox(
                                height: 60,
                                child: Center(child: Icon(Icons.broken_image))),
                          ),
                        ),
                      ),
                    Text(a.text,
                        style: const TextStyle(
                            color: AppColors.textSoft, height: 1.6)),
                    const SizedBox(height: 10),
                    MiniButton('حذف', MiniKind.del, () async {
                      final ok = await confirmDialog(context, 'حذف هذا الإعلان؟');
                      if (ok && context.mounted) {
                        context.read<AppState>().deleteAnnouncement(a.id);
                      }
                    }),
                  ],
                ),
              )),
      ],
    );
  }
}
