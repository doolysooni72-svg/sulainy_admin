import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';

class _ReportRow {
  final String source;
  final int qty;
  final DateTime? date;
  _ReportRow(this.source, this.qty, this.date);
}

class ReportsTab extends StatefulWidget {
  const ReportsTab({super.key});

  @override
  State<ReportsTab> createState() => _ReportsTabState();
}

class _ReportsTabState extends State<ReportsTab> {
  final _search = TextEditingController();
  String? _selectedTitle;
  String _source = 'all'; // all | online | main | kiosk
  DateTime? _from;
  DateTime? _to;

  bool _loading = false;
  List<_ReportRow>? _rows;

  static const _sources = {
    'all': 'كل المصادر',
    'online': 'أونلاين',
    'main': 'بيع النافذة (الفرع الرئيسي)',
    'kiosk': 'الكشك',
  };

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _pickDate(bool isFrom) async {
    final now = DateTime.now();
    final d = await showDatePicker(
      context: context,
      initialDate: (isFrom ? _from : _to) ?? now,
      firstDate: DateTime(2020),
      lastDate: DateTime(now.year + 1),
      locale: const Locale('ar', 'EG'),
    );
    if (d != null) setState(() => isFrom ? _from = d : _to = d);
  }

  String _dateLabel(DateTime? d) => d == null
      ? 'اختر التاريخ'
      : '${d.year}/${d.month.toString().padLeft(2, '0')}/${d.day.toString().padLeft(2, '0')}';

  Future<void> _run() async {
    if (_selectedTitle == null) {
      toast(context, 'الرجاء اختيار منتج أولاً من نتائج البحث تحت خانة الاسم',
          error: true);
      return;
    }
    final state = context.read<AppState>();
    setState(() => _loading = true);

    try {
      final results = await Future.wait([
        state.api.fetchOrdersForReport(_from, _to),
        state.api.fetchPosForReport(_from, _to),
      ]);

      final rows = <_ReportRow>[];

      if (_source == 'all' || _source == 'online') {
        for (final o in results[0]) {
          final date = DateTime.tryParse('${o['created_at']}');
          for (final raw in (o['items'] as List? ?? [])) {
            final it = LineItem.fromJson(Map<String, dynamic>.from(raw));
            if (it.title == _selectedTitle) {
              rows.add(_ReportRow('أونلاين', it.qty, date));
            }
          }
        }
      }

      for (final s in results[1]) {
        final loc = (s['location'] ?? 'main') as String;
        if (_source == 'online') continue;
        if (_source == 'main' && loc != 'main') continue;
        if (_source == 'kiosk' && loc != 'kiosk') continue;

        final label = loc == 'kiosk' ? 'الكشك' : 'بيع النافذة';
        final date = DateTime.tryParse('${s['created_at']}');
        for (final raw in (s['items'] as List? ?? [])) {
          final it = LineItem.fromJson(Map<String, dynamic>.from(raw));
          if (it.title == _selectedTitle) {
            rows.add(_ReportRow(label, it.qty, date));
          }
        }
      }

      rows.sort((a, b) =>
          (b.date ?? DateTime(0)).compareTo(a.date ?? DateTime(0)));
      setState(() => _rows = rows);
    } catch (e) {
      if (mounted) toast(context, 'تعذر تحميل التقرير: $e', error: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final products = context.watch<AppState>().products;
    final q = _search.text.trim().toLowerCase();
    final matches = (q.isEmpty || _selectedTitle != null)
        ? <Product>[]
        : products.where((p) => p.title.toLowerCase().contains(q)).take(6).toList();

    final totalQty = _rows?.fold<int>(0, (s, r) => s + r.qty) ?? 0;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('تقرير مبيعات منتج'),
              const Text('اختر المنتج',
                  style: TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
              const SizedBox(height: 6),
              TextField(
                controller: _search,
                decoration: const InputDecoration(hintText: 'اكتب اسم المنتج...'),
                onChanged: (_) => setState(() => _selectedTitle = null),
              ),
              ...matches.map((p) => InkWell(
                    onTap: () => setState(() {
                      _selectedTitle = p.title;
                      _search.text = p.title;
                    }),
                    child: Container(
                      margin: const EdgeInsets.only(top: 8),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColors.divider),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(child: Text(p.title)),
                          Text('${p.stock} بالمخزون',
                              style:
                                  const TextStyle(color: AppColors.success)),
                        ],
                      ),
                    ),
                  )),
              const SizedBox(height: 14),
              const Text('المصدر',
                  style: TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
              const SizedBox(height: 6),
              DropdownButtonFormField<String>(
                value: _source,
                dropdownColor: AppColors.panelNavy2,
                items: _sources.entries
                    .map((e) =>
                        DropdownMenuItem(value: e.key, child: Text(e.value)))
                    .toList(),
                onChanged: (v) => setState(() => _source = v ?? 'all'),
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(child: _dateField('من تاريخ', _from, () => _pickDate(true))),
                  const SizedBox(width: 10),
                  Expanded(child: _dateField('إلى تاريخ', _to, () => _pickDate(false))),
                ],
              ),
              if (_from != null || _to != null)
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: TextButton(
                    onPressed: () => setState(() {
                      _from = null;
                      _to = null;
                    }),
                    child: const Text('مسح التواريخ',
                        style: TextStyle(color: AppColors.textLabel)),
                  ),
                ),
              const SizedBox(height: 10),
              SilverButton(
                  label: 'عرض التقرير', loading: _loading, onPressed: _run),
            ],
          ),
        ),

        if (_rows != null)
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                        child: SizedBox(
                            height: 84,
                            child: StatTile('$totalQty', 'إجمالي الكمية المباعة'))),
                    const SizedBox(width: 12),
                    Expanded(
                        child: SizedBox(
                            height: 84,
                            child: StatTile('${_rows!.length}', 'عدد العمليات'))),
                  ],
                ),
                const SizedBox(height: 18),
                const SectionTitle('تفاصيل العمليات'),
                if (_rows!.isEmpty)
                  const EmptyText('لا توجد عمليات بيع لهذا المنتج في هذه الفترة')
                else
                  ..._rows!.map((r) => Container(
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        decoration: const BoxDecoration(
                          border: Border(
                              bottom: BorderSide(color: AppColors.divider)),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                                flex: 3,
                                child: Text(r.source,
                                    style: const TextStyle(
                                        color: AppColors.textSoft))),
                            Expanded(
                                flex: 2,
                                child: Text('الكمية: ${r.qty}',
                                    style: const TextStyle(
                                        color: AppColors.priceBlue))),
                            Expanded(
                                flex: 5,
                                child: Text(fmtDate(r.date),
                                    textAlign: TextAlign.end,
                                    style: const TextStyle(
                                        color: AppColors.textMuted,
                                        fontSize: 12))),
                          ],
                        ),
                      )),
              ],
            ),
          ),
      ],
    );
  }

  Widget _dateField(String label, DateTime? value, VoidCallback onTap) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
        const SizedBox(height: 6),
        InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.inputBg,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppColors.borderSilver),
            ),
            child: Row(
              children: [
                const Icon(Icons.calendar_today,
                    size: 15, color: AppColors.textLabel),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(_dateLabel(value),
                      style: TextStyle(
                          fontSize: 13,
                          color: value == null
                              ? AppColors.textDim
                              : AppColors.textMain)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
