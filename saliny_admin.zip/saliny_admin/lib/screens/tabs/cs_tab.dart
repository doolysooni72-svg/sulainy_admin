import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/theme.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';
import 'orders_tab.dart' show OrderCard;
import 'special_orders_tab.dart' show SpecialOrderCard;

/// خدمة العملاء: عرض فقط بدون تعديل أو حذف
class CsTab extends StatelessWidget {
  const CsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        const SectionTitle('الطلبات (عرض فقط)'),
        const Padding(
          padding: EdgeInsets.only(bottom: 14),
          child: Text(
            'هذا العرض للاطلاع على تفاصيل الطلبات لمساعدة العملاء، بدون إمكانية تعديل أو حذف',
            style: TextStyle(color: AppColors.textDim, fontSize: 12.5, height: 1.6),
          ),
        ),
        if (s.orders.isEmpty)
          const Panel(child: EmptyText('لا توجد طلبات'))
        else
          ...s.orders.map((o) => OrderCard(order: o, readOnly: true)),
        const SizedBox(height: 10),
        const SectionTitle('الطلبات الخاصة (عرض فقط)'),
        if (s.specialOrders.isEmpty)
          const Panel(child: EmptyText('لا توجد طلبات خاصة'))
        else
          ...s.specialOrders
              .map((o) => SpecialOrderCard(order: o, readOnly: true)),
      ],
    );
  }
}
