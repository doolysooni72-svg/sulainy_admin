import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';

class DashboardTab extends StatelessWidget {
  const DashboardTab({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final d = s.computeDashboard();
    final resetAt = s.settings.statsResetAt;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        // ---- تصفير الإحصائيات ----
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('تصفير الإحصائيات'),
              Text(
                resetAt != null
                    ? 'تم التصفير في: ${fmtDate(resetAt)} — الأرقام أدناه تشمل ما بعد هذا التاريخ فقط. كل الطلبات ومبيعات النافذة والكشك القديمة محفوظة بالكامل في تبويبي الطلبات وتقارير المبيعات.'
                    : 'لم يتم التصفير من قبل — يتم احتساب كل المبيعات منذ البداية.',
                style: const TextStyle(
                    color: AppColors.textDim, fontSize: 12.5, height: 1.6),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  if (resetAt != null)
                    OutlineBtn(
                      label: 'إظهار كل السجل',
                      fullWidth: false,
                      onPressed: () async {
                        final ok = await confirmDialog(context,
                            'سيتم إلغاء التصفير وإظهار كل المبيعات منذ البداية في الداشبورد مجدداً. متابعة؟');
                        if (ok && context.mounted) {
                          context.read<AppState>().undoStatsReset();
                        }
                      },
                    ),
                  OutlineBtn(
                    label: 'تصفير المبيعات المكتملة',
                    icon: Icons.restart_alt,
                    color: AppColors.danger,
                    fullWidth: false,
                    onPressed: () async {
                      final ok = await confirmDialog(context,
                          'سيتم تصفير "مبيعات مكتملة" و"آخر الطلبات" في الداشبورد إلى الصفر بدءاً من الآن. لن يُحذف أي طلب أو بيع فعلياً — كلها تبقى محفوظة وقابلة للعرض في تبويب الطلبات وتقارير المبيعات. متابعة؟');
                      if (ok && context.mounted) {
                        context.read<AppState>().resetStats();
                      }
                    },
                  ),
                ],
              ),
            ],
          ),
        ),

        // ---- الإحصائيات ----
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.7,
          children: [
            StatTile('${d.totalOrders}', 'إجمالي الطلبات'),
            StatTile(money(d.totalRevenue),
                'مبيعات مكتملة (أونلاين + نافذة + كشك)'),
            StatTile('${d.mainSalesCount}', 'عمليات بيع النافذة'),
            StatTile('${d.kioskSalesCount}', 'عمليات بيع الكشك'),
            StatTile('${d.pendingCount}', 'طلبات قيد الانتظار'),
            StatTile('${d.productsCount}', 'عدد المنتجات'),
            StatTile('${d.lowStock.length}', 'مخزون منخفض'),
          ],
        ),
        const SizedBox(height: 18),

        // ---- مخزون منخفض ----
        if (d.lowStock.isNotEmpty)
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SectionTitle('منتجات مخزونها منخفض'),
                ...d.lowStock.map((p) => Container(
                      padding: const EdgeInsets.symmetric(vertical: 9),
                      decoration: const BoxDecoration(
                        border: Border(
                            bottom: BorderSide(color: AppColors.divider)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(child: Text(p.title)),
                          Pill('متبقي ${p.stock}', PillKind.pending),
                        ],
                      ),
                    )),
              ],
            ),
          ),

        // ---- آخر الطلبات ----
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('آخر الطلبات'),
              if (d.recent.isEmpty)
                const EmptyText('لا توجد طلبات بعد')
              else
                ...d.recent.map((r) => Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: const BoxDecoration(
                        border: Border(
                            bottom: BorderSide(color: AppColors.divider)),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(r.name,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600)),
                                const SizedBox(height: 3),
                                Text('${r.source} • ${fmtDate(r.createdAt)}',
                                    style: const TextStyle(
                                        color: AppColors.textDim,
                                        fontSize: 11.5)),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(money(r.total),
                                  style: const TextStyle(
                                      color: AppColors.priceBlue)),
                              const SizedBox(height: 4),
                              Pill.status(r.done),
                            ],
                          ),
                        ],
                      ),
                    )),
            ],
          ),
        ),
      ],
    );
  }
}
