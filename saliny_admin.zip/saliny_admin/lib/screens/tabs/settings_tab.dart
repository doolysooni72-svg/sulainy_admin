import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../providers/app_state.dart';
import '../../widgets/common.dart';

class SettingsTab extends StatefulWidget {
  const SettingsTab({super.key});

  @override
  State<SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<SettingsTab> {
  final _shopName = TextEditingController();
  final _whatsapp = TextEditingController();
  final _facebook = TextEditingController();
  final _cs = TextEditingController();
  final _location = TextEditingController();
  final _terms = TextEditingController();
  final _newPass = TextEditingController();

  bool _savingSettings = false;
  bool _savingPass = false;
  String? _settingsMsg;
  bool _settingsErr = false;
  String? _passMsg;
  bool _passErr = false;
  bool _filled = false;

  @override
  void dispose() {
    for (final c in [_shopName, _whatsapp, _facebook, _cs, _location, _terms, _newPass]) {
      c.dispose();
    }
    super.dispose();
  }

  void _fillFrom(AppState s) {
    final st = s.settings;
    _shopName.text = st.shopName;
    _whatsapp.text = st.whatsapp;
    _facebook.text = st.facebook;
    _cs.text = st.customerServiceNumber;
    _location.text = st.location;
    _terms.text = st.termsText;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // نملأ الحقول مرة واحدة أول ما الإعدادات توصل (عشان ما نمسحش اللي المستخدم بيكتبه)
    final s = context.read<AppState>();
    if (!_filled && s.settings.shopName.isNotEmpty) {
      _fillFrom(s);
      _filled = true;
    }
  }

  Future<void> _saveSettings() async {
    final sn = _shopName.text.trim();
    final wa = _whatsapp.text.trim();
    if (sn.isEmpty || wa.isEmpty) {
      setState(() {
        _settingsMsg = 'اسم المكتبة ورقم الواتساب مطلوبان';
        _settingsErr = true;
      });
      return;
    }
    final state = context.read<AppState>();
    setState(() {
      _savingSettings = true;
      _settingsMsg = null;
    });
    try {
      await state.api.saveSettings(
        shopName: sn,
        whatsapp: wa,
        facebook: _facebook.text.trim(),
        customerService: _cs.text.trim(),
        location: _location.text.trim(),
        terms: _terms.text,
      );
      await state.loadSettings();
      if (mounted) {
        setState(() {
          _settingsMsg = 'تم حفظ الإعدادات بنجاح';
          _settingsErr = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _settingsMsg = 'خطأ أثناء الحفظ: $e';
          _settingsErr = true;
        });
      }
    } finally {
      if (mounted) setState(() => _savingSettings = false);
    }
  }

  Future<void> _changePass() async {
    final p = _newPass.text;
    if (p.length < 6) {
      setState(() {
        _passMsg = 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
        _passErr = true;
      });
      return;
    }
    setState(() {
      _savingPass = true;
      _passMsg = null;
    });
    try {
      await context.read<AppState>().api.changePassword(p);
      if (mounted) {
        _newPass.clear();
        setState(() {
          _passMsg = 'تم تحديث كلمة المرور بنجاح';
          _passErr = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _passMsg = 'فشل التحديث: $e';
          _passErr = true;
        });
      }
    } finally {
      if (mounted) setState(() => _savingPass = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('بيانات المتجر'),
              LabeledField(label: 'اسم المكتبة', controller: _shopName),
              LabeledField(
                  label: 'رقم الواتساب (بدون +)',
                  controller: _whatsapp,
                  keyboard: TextInputType.phone),
              LabeledField(
                  label: 'رابط صفحة الفيسبوك',
                  controller: _facebook,
                  keyboard: TextInputType.url),
              LabeledField(
                  label: 'رقم خدمة العملاء',
                  controller: _cs,
                  keyboard: TextInputType.phone),
              LabeledField(label: 'موقع المكتبة', controller: _location),
              LabeledField(
                  label: 'نص الشروط والأحكام',
                  controller: _terms,
                  maxLines: 6),
              SilverButton(
                  label: 'حفظ الإعدادات',
                  loading: _savingSettings,
                  onPressed: _saveSettings),
              StatusMsg(_settingsMsg, error: _settingsErr),
            ],
          ),
        ),
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('تغيير كلمة المرور'),
              LabeledField(
                  label: 'كلمة المرور الجديدة',
                  controller: _newPass,
                  obscure: true),
              SilverButton(
                  label: 'تحديث كلمة المرور',
                  loading: _savingPass,
                  onPressed: _changePass),
              StatusMsg(_passMsg, error: _passErr),
            ],
          ),
        ),
      ],
    );
  }
}
