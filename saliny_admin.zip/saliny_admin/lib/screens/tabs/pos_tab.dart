import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';
import '../../widgets/barcode_scanner_page.dart';
import '../../widgets/common.dart';

/// شاشة البيع — نفس الكود لبيع النافذة (kiosk=false) وبيع الكشك (kiosk=true)
class PosTab extends StatefulWidget {
  final bool kiosk;
  const PosTab({super.key, required this.kiosk});

  @override
  State<PosTab> createState() => _PosTabState();
}

class _PosTabState extends State<PosTab> {
  final List<CartItem> _cart = [];
  final _search = TextEditingController();

  bool _completing = false;
  String? _saleMsg;

  // مرحلة الفاتورة
  bool _showInvoice = false;
  String? _saleId;
  List<LineItem> _invoiceItems = [];
  double _invoiceTotal = 0;
  bool _uploading = false;
  String? _receiptMsg;
  bool _receiptError = false;

  String get _location => widget.kiosk ? 'kiosk' : 'main';

  double get _total => _cart.fold(0, (s, c) => s + c.price * c.qty);

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  // ---------- السلة ----------
  void _add(Product p) {
    if (p.stock <= 0) {
      toast(context, 'هذا المنتج غير متوفر في المخزون', error: true);
      return;
    }
    setState(() {
      final existing = _cart.where((c) => c.productId == p.id).firstOrNull;
      if (existing != null) {
        if (existing.qty < p.stock) existing.qty++;
      } else {
        _cart.add(CartItem(
            productId: p.id, title: p.title, price: p.price, maxStock: p.stock));
      }
    });
  }

  Future<void> _scan() async {
    final code = await scanBarcode(context);
    if (code == null || !mounted) return;
    final products = context.read<AppState>().products;
    final p = products.where((x) => x.barcode == code).firstOrNull;
    if (p == null) {
      toast(context, 'لم يتم العثور على منتج بهذا الباركود', error: true);
      return;
    }
    _add(p);
  }

  void _inc(CartItem c) => setState(() {
        if (c.qty < c.maxStock) c.qty++;
      });

  void _dec(CartItem c) => setState(() {
        c.qty--;
        if (c.qty <= 0) _cart.remove(c);
      });

  // ---------- إتمام البيع ----------
  Future<void> _complete() async {
    if (_cart.isEmpty) return;
    final state = context.read<AppState>();
    final snapshot = List<CartItem>.from(_cart);
    final total = _total;

    setState(() {
      _completing = true;
      _saleMsg = null;
    });

    try {
      final id = await state.api.completeSale(
        cart: snapshot,
        location: _location,
        soldBy: state.userId!,
      );
      if (state.role == 'admin') state.loadPosSales();
      await state.loadProducts();

      if (!mounted) return;
      setState(() {
        _saleId = id;
        _invoiceItems = snapshot
            .map((c) => LineItem(title: c.title, price: c.price, qty: c.qty))
            .toList();
        _invoiceTotal = total;
        _cart.clear();
        _receiptMsg = null;
        _showInvoice = true;
      });
    } catch (e) {
      if (mounted) setState(() => _saleMsg = 'خطأ: $e');
    } finally {
      if (mounted) setState(() => _completing = false);
    }
  }

  // ---------- إشعار الحوالة ----------
  Future<void> _captureReceipt() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.camera, imageQuality: 90);
    if (x == null) return;
    if (_saleId == null) {
      setState(() {
        _receiptMsg = 'تعذر ربط الإيصال بعملية البيع';
        _receiptError = true;
      });
      return;
    }
    final state = context.read<AppState>();
    setState(() {
      _uploading = true;
      _receiptMsg = 'جاري رفع الصورة...';
      _receiptError = false;
    });
    try {
      final url = await state.api.uploadImage(
        file: File(x.path),
        bucket: Config.bucketTransfers,
        prefix: widget.kiosk ? '_kiosk' : '_pos',
      );
      await state.api.attachSaleReceipt(_saleId!, url);
      if (mounted) {
        setState(() {
          _receiptMsg = 'تم إرفاق الإشعار بنجاح';
          _receiptError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _receiptMsg = 'خطأ: $e';
          _receiptError = true;
        });
      }
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  void _newSale() => setState(() {
        _saleId = null;
        _receiptMsg = null;
        _showInvoice = false;
      });

  // ---------- الواجهة ----------
  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: _showInvoice ? _invoiceStage() : _saleStage(),
    );
  }

  List<Widget> _saleStage() {
    final products = context.watch<AppState>().products;
    final q = _search.text.trim().toLowerCase();
    final matches = q.isEmpty
        ? <Product>[]
        : products
            .where((p) => p.title.toLowerCase().contains(q))
            .take(6)
            .toList();

    return [
      // ---- البحث / المسح ----
      Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SilverButton(
                label: 'مسح باركود المنتج',
                icon: Icons.qr_code_scanner,
                onPressed: _scan),
            const SizedBox(height: 16),
            LabeledField(
              label: 'أو ابحث بالاسم',
              controller: _search,
              hint: 'اكتب اسم المنتج...',
              onChanged: (_) => setState(() {}),
            ),
            ...matches.map((p) => InkWell(
                  onTap: () {
                    _add(p);
                    _search.clear();
                    setState(() {});
                  },
                  child: Container(
                    margin: const EdgeInsets.only(top: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.divider),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                            child: Text('${p.title} — ${money(p.price)}')),
                        Text('${p.stock} متوفر',
                            style: const TextStyle(color: AppColors.success)),
                      ],
                    ),
                  ),
                )),
          ],
        ),
      ),

      // ---- الفاتورة الحالية ----
      Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionTitle(
                widget.kiosk ? 'فاتورة الكشك الحالية' : 'الفاتورة الحالية'),
            if (_cart.isEmpty)
              const EmptyText('لم تتم إضافة أي منتج بعد')
            else ...[
              ..._cart.map((c) => Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: const BoxDecoration(
                      border: Border(
                          bottom: BorderSide(color: AppColors.divider)),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(c.title,
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w600)),
                              const SizedBox(height: 2),
                              Text(money(c.price),
                                  style: const TextStyle(
                                      color: AppColors.priceBlue)),
                            ],
                          ),
                        ),
                        _QtyBtn('-', () => _dec(c)),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Text('${c.qty}',
                              style: const TextStyle(fontSize: 15)),
                        ),
                        _QtyBtn('+', () => _inc(c)),
                        const SizedBox(width: 10),
                        InkWell(
                          onTap: () => setState(() => _cart.remove(c)),
                          child: Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(color: AppColors.danger),
                            ),
                            child: const Icon(Icons.close,
                                size: 16, color: AppColors.danger),
                          ),
                        ),
                      ],
                    ),
                  )),
              Container(
                margin: const EdgeInsets.only(top: 8, bottom: 16),
                padding: const EdgeInsets.symmetric(vertical: 14),
                decoration: const BoxDecoration(
                  border: Border(top: BorderSide(color: AppColors.borderSilver)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('الإجمالي',
                        style: TextStyle(
                            color: AppColors.textTitle,
                            fontSize: 17,
                            fontWeight: FontWeight.bold)),
                    Text(money(_total),
                        style: const TextStyle(
                            color: AppColors.textTitle,
                            fontSize: 17,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
            ],
            SilverButton(
              label: 'إتمام البيع',
              loading: _completing,
              onPressed: _cart.isEmpty ? null : _complete,
            ),
            StatusMsg(_saleMsg, error: true),
          ],
        ),
      ),
    ];
  }

  List<Widget> _invoiceStage() {
    return [
      Panel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SectionTitle(widget.kiosk
                ? 'تمت عملية بيع الكشك بنجاح'
                : 'تمت عملية البيع بنجاح'),
            Container(
              padding: const EdgeInsets.all(16),
              margin: const EdgeInsets.only(bottom: 18),
              decoration: BoxDecoration(
                color: AppColors.inputBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.borderSilver),
              ),
              child: Column(
                children: [
                  ..._invoiceItems.map((it) => Container(
                        padding: const EdgeInsets.symmetric(vertical: 7),
                        decoration: const BoxDecoration(
                          border: Border(
                              bottom: BorderSide(color: AppColors.divider)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                                child: Text('${it.title} × ${it.qty}',
                                    style: const TextStyle(
                                        color: AppColors.textSoft))),
                            Text(money(it.price * it.qty),
                                style: const TextStyle(
                                    color: AppColors.textSoft)),
                          ],
                        ),
                      )),
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('الإجمالي',
                            style: TextStyle(
                                color: AppColors.textTitle,
                                fontWeight: FontWeight.bold)),
                        Text(money(_invoiceTotal),
                            style: const TextStyle(
                                color: AppColors.textTitle,
                                fontWeight: FontWeight.bold)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            SilverButton(
              label: 'التقاط صورة إشعار الحوالة',
              icon: Icons.photo_camera,
              loading: _uploading,
              onPressed: _captureReceipt,
            ),
            StatusMsg(_receiptMsg, error: _receiptError),
            const SizedBox(height: 10),
            OutlineBtn(label: 'بيع جديد', onPressed: _newSale),
          ],
        ),
      ),
    ];
  }
}

class _QtyBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _QtyBtn(this.label, this.onTap);

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        child: Container(
          width: 30,
          height: 30,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: AppColors.borderSilver),
          ),
          child: Text(label,
              style: const TextStyle(color: AppColors.textLabel, fontSize: 17)),
        ),
      );
}
