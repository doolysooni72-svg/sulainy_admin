import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';

class PaymentTab extends StatefulWidget {
  const PaymentTab({super.key});

  @override
  State<PaymentTab> createState() => _PaymentTabState();
}

class _PaymentTabState extends State<PaymentTab> {
  final _name = TextEditingController();
  final _account = TextEditingController();
  File? _qr;
  bool _saving = false;
  String? _msg;
  bool _msgError = false;

  @override
  void dispose() {
    _name.dispose();
    _account.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => _qr = File(x.path));
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.isEmpty) {
      setState(() {
        _msg = 'الرجاء كتابة اسم البنك أو المحفظة';
        _msgError = true;
      });
      return;
    }
    final state = context.read<AppState>();
    setState(() {
      _saving = true;
      _msg = null;
    });
    try {
      String? url;
      if (_qr != null) {
        try {
          // صور QR بتتحفظ PNG بحجم 900 (نفس النسخة الويب)
          url = await state.api.uploadImage(
            file: _qr!,
            bucket: Config.bucketPaymentQr,
            maxDim: 900,
            quality: 100,
            png: true,
          );
        } catch (e) {
          throw 'تعذر رفع الصورة: $e';
        }
      }
      await state.api.addPaymentMethod(name, _account.text.trim(), url);
      _name.clear();
      _account.clear();
      _qr = null;
      await state.loadPaymentMethods();
      if (mounted) {
        setState(() {
          _msg = 'تمت الإضافة بنجاح';
          _msgError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _msg = e.toString().startsWith('تعذر رفع') ? e.toString() : 'خطأ: $e';
          _msgError = true;
        });
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().paymentMethods;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SectionTitle('إضافة طريقة دفع'),
              LabeledField(label: 'اسم البنك / المحفظة', controller: _name),
              LabeledField(
                  label: 'رقم الحساب (اختياري)', controller: _account),
              const Text('صورة QR (اختياري)',
                  style: TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
              const SizedBox(height: 6),
              Row(
                children: [
                  if (_qr != null)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(_qr!,
                            width: 48, height: 48, fit: BoxFit.cover),
                      ),
                    ),
                  Expanded(
                    child: OutlineBtn(
                      label: _qr == null ? 'اختيار صورة' : 'تغيير الصورة',
                      icon: Icons.qr_code_2,
                      onPressed: _pick,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SilverButton(label: 'إضافة', loading: _saving, onPressed: _save),
              StatusMsg(_msg, error: _msgError),
            ],
          ),
        ),
        const SectionTitle('طرق الدفع الحالية'),
        if (list.isEmpty)
          const Panel(child: EmptyText('لا توجد طرق دفع'))
        else
          ...list.map((p) => Panel(
                padding: const EdgeInsets.all(14),
                margin: const EdgeInsets.only(bottom: 12),
                child: Column(
                  children: [
                    if (p.qrUrl != null && p.qrUrl!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: CachedNetworkImage(
                            imageUrl: p.qrUrl!,
                            height: 170,
                            fit: BoxFit.contain,
                            errorWidget: (_, __, ___) =>
                                const Icon(Icons.broken_image),
                          ),
                        ),
                      ),
                    Text(p.name,
                        style: const TextStyle(
                            color: AppColors.textTitle,
                            fontSize: 16,
                            fontWeight: FontWeight.w600)),
                    if (p.accountNumber != null && p.accountNumber!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: SelectableText('رقم الحساب: ${p.accountNumber}',
                            style: const TextStyle(color: AppColors.textLabel)),
                      ),
                    const SizedBox(height: 10),
                    MiniButton('حذف', MiniKind.del, () async {
                      final ok =
                          await confirmDialog(context, 'حذف طريقة الدفع دي؟');
                      if (ok && context.mounted) {
                        context.read<AppState>().deletePaymentMethod(p.id);
                      }
                    }),
                  ],
                ),
              )),
      ],
    );
  }
}
