import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';
import '../../widgets/barcode_scanner_page.dart';
import '../../widgets/common.dart';

class ProductsTab extends StatefulWidget {
  const ProductsTab({super.key});

  @override
  State<ProductsTab> createState() => _ProductsTabState();
}

class _ProductsTabState extends State<ProductsTab> {
  final _title = TextEditingController();
  final _desc = TextEditingController();
  final _price = TextEditingController();
  final _stock = TextEditingController();
  final _barcode = TextEditingController();
  final _origPrice = TextEditingController();
  final _scroll = ScrollController();

  bool _isOffer = false;
  File? _image;
  String? _editingId;
  String? _editingTitle;
  bool _saving = false;
  String? _msg;
  bool _msgError = false;

  @override
  void dispose() {
    for (final c in [_title, _desc, _price, _stock, _barcode, _origPrice]) {
      c.dispose();
    }
    _scroll.dispose();
    super.dispose();
  }

  void _reset() {
    setState(() {
      _editingId = null;
      _editingTitle = null;
      _image = null;
      _isOffer = false;
      for (final c in [_title, _desc, _price, _stock, _barcode, _origPrice]) {
        c.clear();
      }
    });
  }

  void _edit(Product p) {
    setState(() {
      _editingId = p.id;
      _editingTitle = p.title;
      _title.text = p.title;
      _desc.text = p.description;
      _price.text = _fmtNum(p.price);
      _stock.text = '${p.stock}';
      _barcode.text = p.barcode;
      _origPrice.text = p.originalPrice == null ? '' : _fmtNum(p.originalPrice!);
      _isOffer = p.isOffer;
      _image = null;
      _msg = null;
    });
    _scroll.animateTo(0,
        duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
  }

  String _fmtNum(double v) =>
      v == v.roundToDouble() ? v.toInt().toString() : v.toString();

  Future<void> _pickImage() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (x != null) setState(() => _image = File(x.path));
  }

  Future<void> _scan() async {
    final code = await scanBarcode(context);
    if (code != null) setState(() => _barcode.text = code);
  }

  Future<void> _save() async {
    final title = _title.text.trim();
    final desc = _desc.text.trim();
    final price = double.tryParse(_price.text.trim());
    final stock = int.tryParse(_stock.text.trim());
    final orig = _origPrice.text.trim().isEmpty
        ? null
        : double.tryParse(_origPrice.text.trim());

    if (title.isEmpty || desc.isEmpty || price == null || stock == null) {
      setState(() {
        _msg = 'الرجاء ملء جميع الحقول بشكل صحيح';
        _msgError = true;
      });
      return;
    }

    final state = context.read<AppState>();
    setState(() {
      _saving = true;
      _msg = null;
    });

    try {
      String? imageUrl;
      if (_image != null) {
        try {
          imageUrl = await state.api
              .uploadImage(file: _image!, bucket: Config.bucketProducts);
        } catch (e) {
          throw 'تعذر رفع الصورة: $e';
        }
      }
      await state.api.saveProduct(
        editingId: _editingId,
        title: title,
        description: desc,
        price: price,
        stock: stock,
        isOffer: _isOffer,
        originalPrice: orig,
        barcode: _barcode.text.trim(),
        imageUrl: imageUrl,
      );
      _reset();
      await state.loadProducts();
      if (mounted) {
        setState(() {
          _msg = 'تم الحفظ بنجاح';
          _msgError = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _msg = e.toString().startsWith('تعذر رفع')
              ? e.toString()
              : 'خطأ أثناء الحفظ: $e';
          _msgError = true;
        });
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();

    return ListView(
      controller: _scroll,
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        // ================= الفورم =================
        Panel(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionTitle(_editingId == null
                  ? 'إضافة منتج'
                  : 'تعديل منتج: $_editingTitle'),
              LabeledField(label: 'اسم المنتج', controller: _title),
              LabeledField(label: 'الوصف', controller: _desc),
              LabeledField(
                  label: 'السعر (جنيه)',
                  controller: _price,
                  keyboard: const TextInputType.numberWithOptions(decimal: true)),
              LabeledField(
                  label: 'الكمية المتوفرة',
                  controller: _stock,
                  keyboard: TextInputType.number),
              LabeledField(
                label: 'الباركود (اختياري)',
                controller: _barcode,
                suffix: IconButton(
                  tooltip: 'مسح',
                  icon: const Icon(Icons.qr_code_scanner,
                      color: AppColors.accentBlue),
                  onPressed: _scan,
                ),
              ),
              LabeledField(
                  label: 'السعر قبل الخصم (اختياري)',
                  controller: _origPrice,
                  keyboard: const TextInputType.numberWithOptions(decimal: true)),
              CheckboxListTile(
                value: _isOffer,
                onChanged: (v) => setState(() => _isOffer = v ?? false),
                title: const Text('عرض خاص',
                    style: TextStyle(color: AppColors.textLabel, fontSize: 14)),
                controlAffinity: ListTileControlAffinity.leading,
                contentPadding: EdgeInsets.zero,
                dense: true,
              ),
              const SizedBox(height: 6),
              const Text('صورة المنتج (اختياري)',
                  style: TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
              const SizedBox(height: 6),
              Row(
                children: [
                  if (_image != null)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.file(_image!,
                            width: 48, height: 48, fit: BoxFit.cover),
                      ),
                    ),
                  Expanded(
                    child: OutlineBtn(
                      label: _image == null ? 'اختيار صورة' : 'تغيير الصورة',
                      icon: Icons.image_outlined,
                      onPressed: _pickImage,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SilverButton(
                label: 'حفظ المنتج',
                loading: _saving,
                onPressed: _save,
              ),
              if (_editingId != null) ...[
                const SizedBox(height: 8),
                OutlineBtn(label: 'إلغاء التعديل', onPressed: _reset),
              ],
              StatusMsg(_msg, error: _msgError),
            ],
          ),
        ),

        // ================= القائمة =================
        Panel(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SectionTitle('قائمة المنتجات (${s.products.length})'),
              if (s.products.isEmpty)
                const EmptyText('لا توجد منتجات')
              else
                ...s.products.map((p) => _ProductRow(
                      product: p,
                      onEdit: () => _edit(p),
                      onDelete: () async {
                        final ok = await confirmDialog(
                            context, 'هل أنت متأكد من حذف هذا المنتج؟');
                        if (ok && context.mounted) {
                          context.read<AppState>().deleteProduct(p.id);
                        }
                      },
                    )),
            ],
          ),
        ),
      ],
    );
  }
}

class _ProductRow extends StatelessWidget {
  final Product product;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _ProductRow(
      {required this.product, required this.onEdit, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final p = product;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: AppColors.divider)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Thumb(p.imageUrl),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(p.title,
                    style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Wrap(
                  spacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    Text(money(p.price),
                        style: const TextStyle(color: AppColors.priceBlue)),
                    if (p.isOffer) const Pill('عرض', PillKind.offer),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'المخزون: ${p.stock}  •  الباركود: ${p.barcode.isEmpty ? '-' : p.barcode}',
                  style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 12),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    MiniButton('تعديل', MiniKind.edit, onEdit),
                    const SizedBox(width: 8),
                    MiniButton('حذف', MiniKind.del, onDelete),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
