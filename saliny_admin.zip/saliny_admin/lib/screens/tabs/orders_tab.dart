import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/constants.dart';
import '../../core/theme.dart';
import '../../models/models.dart';
import '../../providers/app_state.dart';
import '../../widgets/common.dart';

/// صف/سطر معلومة (عنوان: قيمة)
class InfoLine extends StatelessWidget {
  final String label;
  final Widget value;
  const InfoLine(this.label, this.value, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 70,
              child: Text(label,
                  style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 12.5)),
            ),
            Expanded(child: value),
          ],
        ),
      );
}

/// كارت طلب — يُستخدم في تبويب الطلبات (بإجراءات) وخدمة العملاء (عرض فقط)
class OrderCard extends StatelessWidget {
  final Order order;
  final bool readOnly;
  const OrderCard({super.key, required this.order, this.readOnly = false});

  @override
  Widget build(BuildContext context) {
    final o = order;
    final state = context.read<AppState>();

    return Panel(
      padding: const EdgeInsets.all(14),
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(o.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15.5)),
              ),
              Pill.status(o.isDone),
            ],
          ),
          const SizedBox(height: 10),
          InfoLine('الهاتف',
              Text(o.phone, style: const TextStyle(color: AppColors.textSoft))),
          InfoLine(
            'العنوان',
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(o.deliveryAddress.isEmpty ? '-' : o.deliveryAddress,
                    style: const TextStyle(color: AppColors.textSoft)),
                if (o.gpsLink.isNotEmpty)
                  InkWell(
                    onTap: () => openLink(context, o.gpsLink),
                    child: const Padding(
                      padding: EdgeInsets.only(top: 3),
                      child: Text('فتح الخريطة',
                          style: TextStyle(
                              color: AppColors.priceBlue,
                              decoration: TextDecoration.underline)),
                    ),
                  ),
              ],
            ),
          ),
          InfoLine(
              'المنتجات',
              Text(o.itemsText.isEmpty ? '-' : o.itemsText,
                  style: const TextStyle(color: AppColors.textSoft))),
          InfoLine('الإجمالي',
              Text(money(o.total),
                  style: const TextStyle(
                      color: AppColors.priceBlue, fontWeight: FontWeight.bold))),
          if (!readOnly)
            InfoLine(
              'الإيصال',
              o.receiptUrl.isEmpty
                  ? const Text('-',
                      style: TextStyle(color: AppColors.textSoft))
                  : InkWell(
                      onTap: () => openLink(context, o.receiptUrl),
                      child: const Text('عرض الإيصال',
                          style: TextStyle(
                              color: AppColors.priceBlue,
                              decoration: TextDecoration.underline)),
                    ),
            ),
          InfoLine('التاريخ',
              Text(fmtDate(o.createdAt),
                  style: const TextStyle(color: AppColors.textSoft))),
          if (!readOnly) ...[
            const SizedBox(height: 8),
            Row(
              children: [
                if (!o.isDone) ...[
                  MiniButton('إتمام', MiniKind.done,
                      () => state.markOrderDone(o.id)),
                  const SizedBox(width: 8),
                ],
                MiniButton('حذف', MiniKind.del, () async {
                  final ok = await confirmDialog(context, 'حذف هذا الطلب؟');
                  if (ok) state.deleteOrder(o.id);
                }),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

class OrdersTab extends StatelessWidget {
  const OrdersTab({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<AppState>().orders;

    return ListView(
      physics: const AlwaysScrollableScrollPhysics(),
      padding: const EdgeInsets.all(16),
      children: [
        SectionTitle('كل الطلبات (${orders.length})'),
        if (orders.isEmpty)
          const Panel(child: EmptyText('لا توجد طلبات'))
        else
          ...orders.map((o) => OrderCard(order: o)),
      ],
    );
  }
}
