import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/app_state.dart';
import '../widgets/common.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _email.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _login() async {
    final email = _email.text.trim();
    final pass = _pass.text;
    if (email.isEmpty || pass.isEmpty) {
      setState(() => _error = 'الرجاء إدخال البريد وكلمة المرور');
      return;
    }
    setState(() => _error = null);
    final err = await context.read<AppState>().login(email, pass);
    if (!mounted) return;
    if (err != null) setState(() => _error = err);
  }

  @override
  Widget build(BuildContext context) {
    final loading = context.watch<AppState>().loggingIn;

    return Scaffold(
      body: GlowBackground(
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 400),
                child: Panel(
                  padding: const EdgeInsets.all(28),
                  margin: EdgeInsets.zero,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const SilverText('مكتبة السليني', size: 28),
                      const SizedBox(height: 6),
                      const Text('لوحة التحكم',
                          style: TextStyle(
                              color: Color(0xFF7D8BA0),
                              fontSize: 13,
                              letterSpacing: 3)),
                      const SizedBox(height: 28),
                      LabeledField(
                        label: 'البريد الإلكتروني',
                        controller: _email,
                        keyboard: TextInputType.emailAddress,
                      ),
                      LabeledField(
                        label: 'كلمة المرور',
                        controller: _pass,
                        obscure: true,
                      ),
                      SilverButton(
                        label: 'دخول',
                        loading: loading,
                        onPressed: _login,
                      ),
                      StatusMsg(_error, error: true),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
