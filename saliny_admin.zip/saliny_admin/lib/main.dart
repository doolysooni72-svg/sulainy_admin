import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/constants.dart';
import 'core/theme.dart';
import 'providers/app_state.dart';
import 'screens/home_shell.dart';
import 'screens/login_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ar_EG');

  await Supabase.initialize(
    url: Config.supabaseUrl,
    anonKey: Config.supabaseKey,
  );

  runApp(
    ChangeNotifierProvider(
      create: (_) => AppState(),
      child: const SalinyApp(),
    ),
  );
}

class SalinyApp extends StatelessWidget {
  const SalinyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'لوحة التحكم - مكتبة السليني',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      // RTL عربي كامل
      locale: const Locale('ar', 'EG'),
      supportedLocales: const [Locale('ar', 'EG')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: Consumer<AppState>(
        builder: (_, s, __) =>
            s.isLoggedIn ? const HomeShell() : const LoginScreen(),
      ),
    );
  }
}
