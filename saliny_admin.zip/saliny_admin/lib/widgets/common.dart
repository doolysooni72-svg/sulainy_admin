import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/theme.dart';

/// خلفية متوهجة زي الـ bg-glow في النسخة الويب
class GlowBackground extends StatelessWidget {
  final Widget child;
  const GlowBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(color: AppColors.bgNavy),
      child: Stack(
        children: [
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(-0.4, -0.6),
                  radius: 1.0,
                  colors: [
                    AppColors.accentBlue.withAlpha(56),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0.7, 0.8),
                  radius: 1.1,
                  colors: [
                    const Color(0x591E3A5F),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }
}

/// نص بتدرج فضي (اسم المكتبة والعناوين)
class SilverText extends StatelessWidget {
  final String text;
  final double size;
  final FontWeight weight;
  const SilverText(this.text,
      {super.key, this.size = 20, this.weight = FontWeight.bold});

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (r) => AppColors.silverGradient.createShader(r),
      child: Text(
        text,
        style: TextStyle(
            fontSize: size, fontWeight: weight, color: Colors.white),
      ),
    );
  }
}

/// بانل زي .panel
class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets margin;
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.margin = const EdgeInsets.only(bottom: 18),
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: AppColors.panelNavy,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderSilver),
      ),
      child: child,
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Text(text,
            style: const TextStyle(
                color: AppColors.textTitle,
                fontSize: 17,
                fontWeight: FontWeight.w600)),
      );
}

/// الزر الفضي الرئيسي
class SilverButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool loading;
  const SilverButton({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = onPressed != null && !loading;
    return Opacity(
      opacity: enabled ? 1 : .55,
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          gradient: enabled ? AppColors.silverGradient : null,
          color: enabled ? null : const Color(0xFF2A3441),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: enabled ? onPressed : null,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 13),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (loading)
                    const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: AppColors.panelNavy),
                    )
                  else if (icon != null)
                    Icon(icon, size: 18, color: AppColors.panelNavy),
                  if (loading || icon != null) const SizedBox(width: 8),
                  Text(label,
                      style: TextStyle(
                        color: enabled
                            ? AppColors.panelNavy
                            : const Color(0xFF66748A),
                        fontWeight: FontWeight.bold,
                      )),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

/// زر بحدود (إلغاء / ثانوي)
class OutlineBtn extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color color;
  final bool fullWidth;
  const OutlineBtn({
    super.key,
    required this.label,
    this.onPressed,
    this.icon,
    this.color = AppColors.textLabel,
    this.fullWidth = true,
  });

  @override
  Widget build(BuildContext context) {
    final btn = OutlinedButton.icon(
      onPressed: onPressed,
      icon: icon == null ? const SizedBox.shrink() : Icon(icon, size: 16),
      label: Text(label),
      style: OutlinedButton.styleFrom(
        foregroundColor: color,
        side: BorderSide(
            color: color == AppColors.textLabel ? AppColors.borderSilver : color),
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
    return fullWidth ? SizedBox(width: double.infinity, child: btn) : btn;
  }
}

enum PillKind { pending, done, offer }

class Pill extends StatelessWidget {
  final String text;
  final PillKind kind;
  const Pill(this.text, this.kind, {super.key});

  Color get _c => switch (kind) {
        PillKind.pending => AppColors.warning,
        PillKind.done => AppColors.success,
        PillKind.offer => AppColors.offer,
      };

  factory Pill.status(bool done) => Pill(
        done ? 'مكتمل' : 'قيد الانتظار',
        done ? PillKind.done : PillKind.pending,
      );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _c),
      ),
      child: Text(text, style: TextStyle(color: _c, fontSize: 11.5)),
    );
  }
}

/// أزرار صغيرة (تعديل / حذف / إتمام)
enum MiniKind { done, del, edit }

class MiniButton extends StatelessWidget {
  final String label;
  final MiniKind kind;
  final VoidCallback onPressed;
  const MiniButton(this.label, this.kind, this.onPressed, {super.key});

  @override
  Widget build(BuildContext context) {
    final (bg, fg) = switch (kind) {
      MiniKind.done => (AppColors.successBg, AppColors.success),
      MiniKind.del => (AppColors.dangerBg, AppColors.danger),
      MiniKind.edit => (AppColors.editBg, AppColors.priceBlue),
    };
    return Material(
      color: bg,
      borderRadius: BorderRadius.circular(6),
      child: InkWell(
        borderRadius: BorderRadius.circular(6),
        onTap: onPressed,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          child: Text(label, style: TextStyle(color: fg, fontSize: 12.5)),
        ),
      ),
    );
  }
}

/// كارت إحصائية
class StatTile extends StatelessWidget {
  final String value;
  final String label;
  const StatTile(this.value, this.label, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.panelNavy,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderSilver),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          FittedBox(
              fit: BoxFit.scaleDown, child: SilverText(value, size: 22)),
          const SizedBox(height: 4),
          Text(label,
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.textMuted, fontSize: 11.5)),
        ],
      ),
    );
  }
}

/// صورة مصغّرة للمنتج
class Thumb extends StatelessWidget {
  final String? url;
  final double size;
  const Thumb(this.url, {super.key, this.size = 48});

  @override
  Widget build(BuildContext context) {
    if (url == null || url!.isEmpty) {
      return Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: AppColors.inputBg,
          borderRadius: BorderRadius.circular(6),
        ),
        child: const Icon(Icons.menu_book, color: AppColors.textDim, size: 22),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(6),
      child: CachedNetworkImage(
        imageUrl: url!,
        width: size,
        height: size,
        fit: BoxFit.cover,
        errorWidget: (_, __, ___) => Container(
          width: size,
          height: size,
          color: AppColors.inputBg,
          child: const Icon(Icons.broken_image, color: AppColors.textDim),
        ),
      ),
    );
  }
}

class EmptyText extends StatelessWidget {
  final String text;
  const EmptyText(this.text, {super.key});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(18),
        child: Center(
            child: Text(text,
                style: const TextStyle(color: AppColors.textDim))),
      );
}

/// نتيجة عملية: رسالة نجاح / خطأ صغيرة تحت الفورم
class StatusMsg extends StatelessWidget {
  final String? text;
  final bool error;
  const StatusMsg(this.text, {super.key, this.error = false});

  @override
  Widget build(BuildContext context) {
    if (text == null || text!.isEmpty) return const SizedBox.shrink();
    final c = error ? AppColors.danger : AppColors.success;
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: c),
      ),
      child: Text(text!, style: TextStyle(color: c, fontSize: 13)),
    );
  }
}

/// حقل نصي بعنوان فوقه
class LabeledField extends StatelessWidget {
  final String label;
  final TextEditingController controller;
  final TextInputType? keyboard;
  final int maxLines;
  final bool obscure;
  final String? hint;
  final ValueChanged<String>? onChanged;
  final Widget? suffix;

  const LabeledField({
    super.key,
    required this.label,
    required this.controller,
    this.keyboard,
    this.maxLines = 1,
    this.obscure = false,
    this.hint,
    this.onChanged,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: AppColors.textLabel, fontSize: 13.5)),
          const SizedBox(height: 6),
          TextField(
            controller: controller,
            keyboardType: keyboard,
            maxLines: obscure ? 1 : maxLines,
            minLines: maxLines > 1 ? 3 : 1,
            obscureText: obscure,
            onChanged: onChanged,
            decoration: InputDecoration(hintText: hint, suffixIcon: suffix),
          ),
        ],
      ),
    );
  }
}

// ============ Helpers ============
Future<bool> confirmDialog(BuildContext context, String message) async {
  final res = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      content: Text(message,
          style: const TextStyle(color: AppColors.textMain, height: 1.6)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx, false),
          child: const Text('إلغاء',
              style: TextStyle(color: AppColors.textLabel)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, true),
          child: const Text('تأكيد',
              style: TextStyle(color: AppColors.accentBlue)),
        ),
      ],
    ),
  );
  return res ?? false;
}

void toast(BuildContext context, String msg, {bool error = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(color: error ? AppColors.danger : AppColors.textMain)),
    ));
}

Future<void> openLink(BuildContext context, String url) async {
  final uri = Uri.tryParse(url);
  if (uri == null || !await launchUrl(uri, mode: LaunchMode.externalApplication)) {
    if (context.mounted) toast(context, 'تعذر فتح الرابط', error: true);
  }
}
